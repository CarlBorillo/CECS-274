import sys
data = []
b_1 = 0
for k in range(20):
    a = len(data) #Number of elements in the range
    b_2 = sys.getsizeof(data) #actual size in bytes
    data.append(None) #increases length by one
    if b_1 > b_2 and a_1 > 0: #Checks if the increase in length changes the byte size of the array
        b_1 == b_2
        print(a - 1, end=', ')
    data.append(None)
